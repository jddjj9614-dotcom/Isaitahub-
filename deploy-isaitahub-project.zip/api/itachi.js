// Función serverless de Vercel que responde en /itachi como texto plano.
// La reescritura de /itachi -> /api/itachi está definida en vercel.json.
export default function handler(req, res) {
  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");

  const body = `loadstring(game:HttpGet("https://raw.githubusercontent.com/jddjj9614-dotcom/Itachi_scripts../refs/heads/main/Movimiento%20tela%20IsaitaHub"))()`;

  res.status(200).send(body);
}
